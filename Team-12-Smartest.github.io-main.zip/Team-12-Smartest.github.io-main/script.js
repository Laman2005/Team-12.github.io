
//let myName = 'Natalia';
//let myCity = 'Mexico City';

//console.log(`My name is ${myName}. My favorite city is ${myCity}.`)

ent.write("<h2 style='color:blue;'>Javascript rules!</h2>);
    ent.write("<hr/>");

let person = 'Laman';

if (person === 'Laman') {
    console.log('The information about Laman');
} else if (person === 'Kawthar') {
    console.log('The information about Kawthar');
} else if (person === 'Asgar') {
    console.log('The information about Asgar');
} else if (person === 'Ismayil') {
    console.log('The information about Ismayil');
} else {
    console.log('Invalid person.');
}


const find me = function (student) {
    if (student === 'ADA student') {
        return true;
    }
    else {
        return false;
    }
}
find me('MIT student');
console.log(find me('MIT student'))

